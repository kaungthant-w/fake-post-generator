<?php
ob_start();
/*
Plugin Name: Fake Post Generator
Description: A plugin to generate fake posts with Japanese or English text.
Version: 1.1
Author: Kyaw Myo Thant
Tags: <?php echo site_url('/wp-admin/admin.php?page=fake-post-generator'); ?>
Text Domain: fake-post-generator
*/

add_filter('plugin_row_meta', 'add_view_details_link', 10, 2);

function add_view_details_link($links, $file) {
    if ($file == plugin_basename(__FILE__)) {
        $view_details_link = '<a href="' . admin_url('admin.php?page=fake-post-generator') . '">Go to Generator</a>';
        $links[] = $view_details_link;
    }
    return $links;
}

function fake_post_generator_styles($hook) {
    if ($hook != 'toplevel_page_fake-post-generator') {
        return;
    }
    wp_enqueue_style('fake-post-generator-styles', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('admin_enqueue_scripts', 'fake_post_generator_styles');

register_activation_hook(__FILE__, 'generate_fake_posts_on_activation');

function generate_fake_posts_on_activation() {
    generate_fake_posts(30, 3, 5, 15, 'jp', date('Y-m-d H:i:s'));
}

function generate_random_paragraph($min_words = 5, $max_words = 15, $language = 'jp') {
    if ($language == 'jp') {
        $word_list = explode(' ', 'これは日本語のダミーテキストです。適当に日本語の単語を並べています。文章の内容には特に意味はありません。ランダムな日本語の単語を使って文章を生成します。');
    } else {
        $word_list = explode(' ', 'This is a dummy text in English. Random English words are arranged. The content of the sentence does not have any particular meaning. Sentences are generated using random English words.');
    }
    $word_count = rand($min_words, $max_words);
    $paragraph = array();

    for ($i = 0; $i < $word_count; $i++) {
        $paragraph[] = $word_list[array_rand($word_list)];
    }

    return implode(' ', $paragraph);
}

function generate_multiple_paragraphs($num_paragraphs = 3, $min_words = 5, $max_words = 15, $language = 'jp') {
    $content = '';
    for ($i = 0; $i < $num_paragraphs; $i++) {
        $content .= '<p>' . generate_random_paragraph($min_words, $max_words, $language) . '</p>';
    }
    return $content;
}

function generate_fake_posts($num_posts, $num_paragraphs, $min_words, $max_words, $language, $post_date, $categories) {

    // Ensure at least one category is assigned
    if (empty($categories)) {
        $categories = array(1); // Default category ID
    }
    
    for ($i = 1; $i <= $num_posts; $i++) {
        $post_content = generate_multiple_paragraphs($num_paragraphs, $min_words, $max_words, $language);

        $post_data = array(
            'post_title'    => ($language == 'jp' ? 'フェイクポストタイトル ' : 'Fake Post Title ') . $i,
            'post_content'  => $post_content,
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_category' => $categories,
            'tags_input'    => array('New'),
            'post_date'     => $post_date
        );

        wp_insert_post($post_data);
    }
}

function delete_all_posts() {
    $all_posts = get_posts(array('numberposts' => -1, 'post_type' => 'post', 'post_status' => 'any'));
    foreach ($all_posts as $post) {
        wp_delete_post($post->ID, true);
    }
}

function fake_post_generator_admin_notice() {
    if (get_option('fake_posts_generated')) {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e('フェイクポストが正常に作成されました！', 'fake-post-generator'); ?></p>
        </div>
        <?php
        delete_option('fake_posts_generated');
    }
}
add_action('admin_notices', 'fake_post_generator_admin_notice');

add_action('admin_menu', 'fake_post_generator_menu');

function fake_post_generator_menu() {
    add_menu_page(
        'Fake Post Generator',
        'Fake Post Generator',
        'manage_options',
        'fake-post-generator',
        'fake_post_generator_page',
        'dashicons-edit',
        6
    );
}

function fake_post_generator_page() {
    if (isset($_POST['generate_posts'])) {
        check_admin_referer('generate_fake_posts_action');
    
        $num_posts = intval($_POST['num_posts']);
        $num_paragraphs = intval($_POST['num_paragraphs']);
        $min_words = intval($_POST['min_words']);
        $max_words = intval($_POST['max_words']);
        $language = $_POST['language'] == 'eng' ? 'eng' : 'jp';
        $post_date = date('Y-m-d H:i:s', strtotime($_POST['change_date'] . ' ' . date('H:i:s')));
        $categories = isset($_POST['categories']) ? array_map('intval', $_POST['categories']) : array();
    
        // Add appropriate category based on language
        if ($language == 'jp') {
            $category_id = get_cat_ID('お知らせ');
            if ($category_id == 0) {
                $category_id = wp_create_category('お知らせ');
            }
        } else {
            $category_id = get_cat_ID('notice');
            if ($category_id == 0) {
                $category_id = wp_create_category('notice');
            }
        }
        $categories[] = $category_id;
    
        generate_fake_posts($num_posts, $num_paragraphs, $min_words, $max_words, $language, $post_date, $categories);
        update_option('fake_posts_generated', true);
    
        wp_redirect(admin_url('admin.php?page=fake-post-generator'));
        exit;
    }

    if (isset($_POST['delete_posts'])) {
        check_admin_referer('generate_fake_posts_action');

        delete_all_posts();

        wp_redirect(admin_url('admin.php?page=fake-post-generator'));
        exit;
    }

    ?>
    <div class=wrap><h1>Fake Post Generator</h1><form method=post><?php wp_nonce_field('generate_fake_posts_action'); ?><div class=formGroupInput><div class=inputBlock><input name=language type=radio value=jp id=jpText checked> <label for=jpText>日本語 (Japanese)</label></div><div class=inputBlock><input name=language type=radio value=eng id=engText> <label for=engText>英語 (English)</label></div></div><div class=formGroup><label for=change_date>生成する日付 <span class=subTitle>(Choose Date)</span>:</label> <input name=change_date type=date value=30 id=change_date min=1></div><div class=formGroup><label for=num_posts>生成する投稿数 <span class=subTitle>(Number of posts)</span>:</label> <input name=num_posts type=number value=30 id=num_posts min=1></div><div class=formGroup><label for=num_paragraphs>段落数 <span class=subTitle>(Number of paragraphs):</span></label> <input name=num_paragraphs type=number value=3 id=num_paragraphs min=1></div><div class=formGroup><label for=min_words>最小単語数 <span class=subTitle>(Mini number of Sentence):</span></label> <input name=min_words type=number value=2 id=min_words min=1></div><div class=formGroup><label for=max_words>最大単語数 <span class=subTitle>(Max number of Sentence):</span></label> <input name=max_words type=number value=6 id=max_words min=1></div><div class=formGroup><input name=generate_posts type=submit value="Generate Posts"class="button button-primary"> <input name=delete_posts type=submit value="Delete All Posts"class="button button-danger"></div></form></div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var today = new Date().toISOString().split('T')[0];
            document.getElementById('change_date').value = today;
        });
    </script>
    <?php

    ob_end_flush();
}